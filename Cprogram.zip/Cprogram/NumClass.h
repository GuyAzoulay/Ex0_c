#ifndef NUMCLASS_H
#define NUMCLASS_H

int isPrime(int);
int isStrong(int);
int isPalindrome(int);
int isArmstrong(int);

#endif
